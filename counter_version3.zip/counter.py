from flask import Flask, render_template, session, redirect, url_for

app = Flask(__name__)
app.secret_key = 'kickflip'

@app.route('/')
def index():
    session['visit_count'] = session.get('visit_count', 0) + 1
    return render_template('counter.html', visit_count=session['visit_count'])

@app.route('/destroy_session')
def destroy_session():
    session.clear()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True, host="localhost", port=8000)
